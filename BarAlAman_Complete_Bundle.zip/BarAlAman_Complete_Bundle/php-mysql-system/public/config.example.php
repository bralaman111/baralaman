<?php
// بعد إنشاء قاعدة البيانات، ضع بياناتها هنا ثم احذف install.php.
return [
  'db_host' => 'localhost',
  'db_name' => 'YOUR_DATABASE',
  'db_user' => 'YOUR_DB_USER',
  'db_pass' => 'YOUR_DB_PASSWORD',
  'base_url' => '',
  'app_name' => 'جمعية بر الأمان الخيرية',
  'phone' => '+963988250670'
];
