<?php
session_start(); $cfg=require __DIR__.'/../config.php';
$pdo=new PDO("mysql:host={$cfg['db_host']};dbname={$cfg['db_name']};charset=utf8mb4",$cfg['db_user'],$cfg['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function auth(){if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}}
