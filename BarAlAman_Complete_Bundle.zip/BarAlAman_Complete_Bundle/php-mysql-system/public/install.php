<?php
// افتح هذا الملف مرة واحدة بعد إنشاء قاعدة البيانات. أنشئ مديرًا ثم احذف install.php.
$msg='';$done=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $cfg=require __DIR__.'/config.php';
  $pdo=new PDO("mysql:host={$cfg['db_host']};dbname={$cfg['db_name']};charset=utf8mb4",$cfg['db_user'],$cfg['db_pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  $sql=file_get_contents(__DIR__.'/../database.sql');
  $pdo->exec($sql);
  $q=$pdo->prepare("INSERT INTO admins(name,email,password_hash) VALUES(?,?,?)");
  $q->execute([trim($_POST['name']),trim($_POST['email']),password_hash($_POST['password'],PASSWORD_DEFAULT)]);
  $done=true;
 }catch(Throwable $e){$msg=$e->getMessage();}
}
?><!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>تثبيت بر الأمان</title><style>body{font-family:Tahoma;background:#f4f7f5;padding:30px}.box{max-width:550px;margin:auto;background:#fff;padding:28px;border-radius:20px}input{width:100%;padding:12px;margin:7px 0 15px;box-sizing:border-box}button{background:#0b5b49;color:#fff;padding:12px 22px;border:0;border-radius:10px}</style><div class="box"><h1>تثبيت نظام بر الأمان</h1><?php if($done):?><h2>تم التثبيت بنجاح</h2><p>احذف install.php ثم ادخل إلى <b>/admin/login.php</b></p><?php else:?><p><?=htmlspecialchars($msg)?></p><form method="post"><input name="name" required placeholder="اسم المدير"><input name="email" type="email" required placeholder="البريد الإلكتروني"><input name="password" type="password" required minlength="8" placeholder="كلمة المرور"><button>تثبيت النظام</button></form><?php endif;?></div>