CREATE TABLE admins (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE posts (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(255) NOT NULL,
 type ENUM('case','news','activity','report') NOT NULL DEFAULT 'news',
 excerpt TEXT,
 body TEXT,
 image VARCHAR(255),
 status ENUM('draft','published') NOT NULL DEFAULT 'draft',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX(status,type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE requests (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 kind ENUM('help','complaint','contact') NOT NULL,
 name VARCHAR(160) NOT NULL,
 phone VARCHAR(40) NOT NULL,
 message TEXT NOT NULL,
 status ENUM('new','reviewing','closed') NOT NULL DEFAULT 'new',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX(status,kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE settings (
 setting_key VARCHAR(80) PRIMARY KEY,
 setting_value TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO settings(setting_key,setting_value) VALUES
('site_name','جمعية بر الأمان الخيرية'),
('tagline','يدًا بيد نصنع المعجزة'),
('phone','+963988250670'),
('hero_text','نعمل على تحويل التكافل إلى أثر حقيقي يصل إلى الإنسان في وقت حاجته.')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);
